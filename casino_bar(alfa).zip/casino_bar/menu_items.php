<?php
// menu_items.php - исправленная версия

// Включаем буферизацию вывода
ob_start();

require_once 'config.php';
require_once 'header.php';

// Проверка авторизации
if (isGuest()) {
    ob_end_clean();
    header('Location: login.php');
    exit;
}

// Демо-режим (если БД не работает)
$demo_mode = true;

// Обработка добавления/редактирования
$message = '';
if (isset($_GET['success'])) {
    $message = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Изменения сохранены!</div>';
}
?>

<div class="container">
    <h1><i class="fas fa-champagne-glasses"></i> Меню казино</h1>
    
    <?php echo $message; ?>
    
    <?php if ($demo_mode): ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i> Режим демонстрации: используются тестовые данные
    </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header">
            <h3>Позиции меню</h3>
            <div class="action-buttons">
                <a href="?add" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Добавить позицию
                </a>
                <button class="btn btn-secondary" onclick="refreshMenu()">
                    <i class="fas fa-sync-alt"></i> Обновить
                </button>
            </div>
        </div>
        
        <div class="card-body">
            <!-- Фильтры -->
            <div class="filters">
                <div class="filter-group">
                    <label for="filterCategory"><i class="fas fa-filter"></i> Категория:</label>
                    <select id="filterCategory" class="filter-select">
                        <option value="">Все</option>
                        <option value="alcohol">Алкоголь</option>
                        <option value="snacks">Закуски</option>
                        <option value="desserts">Десерты</option>
                        <option value="drinks">Напитки</option>
                        <option value="games">Игры</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="filterAvailability"><i class="fas fa-check-circle"></i> Доступность:</label>
                    <select id="filterAvailability" class="filter-select">
                        <option value="">Все</option>
                        <option value="available">Доступно</option>
                        <option value="unavailable">Недоступно</option>
                    </select>
                </div>
            </div>
            
            <!-- Таблица меню -->
            <div class="table-responsive">
                <table class="data-table" id="menuTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Название</th>
                            <th>Категория</th>
                            <th>Описание</th>
                            <th>Цена</th>
                            <th>Доступно</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Тестовые данные (вместо БД)
                        $menuItems = [
                            [
                                'id' => 1,
                                'name' => 'Пиво Балтика',
                                'category' => 'alcohol',
                                'description' => 'Пиво Балтика №7, 0.5л',
                                'price' => 200,
                                'is_available' => 1,
                                'created_at' => '2024-01-15 12:00:00'
                            ],
                            [
                                'id' => 2,
                                'name' => 'Виски Джемсон',
                                'category' => 'alcohol',
                                'description' => 'Виски Jameson, 50мл',
                                'price' => 350,
                                'is_available' => 1,
                                'created_at' => '2024-01-15 12:00:00'
                            ],
                            [
                                'id' => 3,
                                'name' => 'Картофель фри',
                                'category' => 'snacks',
                                'description' => 'Хрустящий картофель фри с соусом',
                                'price' => 300,
                                'is_available' => 1,
                                'created_at' => '2024-01-15 12:00:00'
                            ],
                            [
                                'id' => 4,
                                'name' => 'Клубничный мохито',
                                'category' => 'drinks',
                                'description' => 'Освежающий безалкогольный коктейль',
                                'price' => 250,
                                'is_available' => 1,
                                'created_at' => '2024-01-16 10:00:00'
                            ],
                            [
                                'id' => 5,
                                'name' => 'Шоколадный фондан',
                                'category' => 'desserts',
                                'description' => 'Теплый шоколадный кекс с жидкой серединкой',
                                'price' => 400,
                                'is_available' => 1,
                                'created_at' => '2024-01-16 10:00:00'
                            ],
                            [
                                'id' => 6,
                                'name' => 'Премиум рулетка',
                                'category' => 'games',
                                'description' => 'Игра в рулетку (минимальная ставка 1000₽)',
                                'price' => 1000,
                                'is_available' => 1,
                                'created_at' => '2024-01-16 11:00:00'
                            ]
                        ];
                        
                        foreach ($menuItems as $item):
                            $categoryNames = [
                                'alcohol' => 'Алкоголь',
                                'snacks' => 'Закуски',
                                'desserts' => 'Десерты',
                                'drinks' => 'Напитки',
                                'games' => 'Игры'
                            ];
                        ?>
                        <tr data-category="<?php echo $item['category']; ?>" 
                            data-available="<?php echo $item['is_available'] ? 'available' : 'unavailable'; ?>">
                            <td><?php echo $item['id']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($item['name']); ?></strong>
                            </td>
                            <td>
                                <span class="category-badge category-<?php echo $item['category']; ?>">
                                    <?php echo $categoryNames[$item['category']] ?? ucfirst($item['category']); ?>
                                </span>
                            </td>
                            <td class="description-cell">
                                <?php echo htmlspecialchars($item['description'] ?? 'Нет описания'); ?>
                            </td>
                            <td class="amount-cell">
                                <span class="price-value"><?php echo number_format($item['price'], 0); ?></span> ₽
                            </td>
                            <td>
                                <span class="availability-badge availability-<?php echo $item['is_available'] ? 'yes' : 'no'; ?>">
                                    <?php echo $item['is_available'] ? '✓ Доступно' : '✗ Недоступно'; ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <a href="?edit=<?php echo $item['id']; ?>" 
                                       class="btn-action btn-edit" title="Редактировать">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete=<?php echo $item['id']; ?>" 
                                       class="btn-action btn-delete" 
                                       title="Удалить"
                                       onclick="return confirm('Удалить позицию \"<?php echo addslashes($item['name']); ?>\"?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Статистика меню -->
            <div class="menu-stats">
                <div class="stat-card mini">
                    <h4><i class="fas fa-list"></i> Всего позиций</h4>
                    <p id="totalItems"><?php echo count($menuItems); ?></p>
                </div>
                <div class="stat-card mini">
                    <h4><i class="fas fa-wine-glass-alt"></i> Алкоголь</h4>
                    <p id="alcoholItems">2</p>
                </div>
                <div class="stat-card mini">
                    <h4><i class="fas fa-utensils"></i> Закуски</h4>
                    <p id="snackItems">1</p>
                </div>
                <div class="stat-card mini">
                    <h4><i class="fas fa-check-circle"></i> Доступно</h4>
                    <p id="availableItems"><?php echo count($menuItems); ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Форма добавления/редактирования -->
    <?php if (isset($_GET['add']) || isset($_GET['edit'])): 
        $is_edit = isset($_GET['edit']);
        $item_id = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
        
        // Находим редактируемую позицию
        $edit_item = null;
        if ($is_edit && $item_id > 0) {
            foreach ($menuItems as $item) {
                if ($item['id'] == $item_id) {
                    $edit_item = $item;
                    break;
                }
            }
        }
    ?>
    <div class="card mt-4">
        <div class="card-header">
            <h3>
                <i class="fas <?php echo $is_edit ? 'fa-edit' : 'fa-plus-circle'; ?>"></i>
                <?php echo $is_edit ? 'Редактирование позиции' : 'Добавление новой позиции'; ?>
            </h3>
        </div>
        <div class="card-body">
            <form id="menuItemForm" class="menu-form">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="itemName">
                            <i class="fas fa-tag"></i> Название позиции:
                        </label>
                        <input type="text" id="itemName" class="form-control" 
                               value="<?php echo $edit_item ? htmlspecialchars($edit_item['name']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="itemCategory">
                            <i class="fas fa-list"></i> Категория:
                        </label>
                        <select id="itemCategory" class="form-control" required>
                            <option value="">Выберите категорию</option>
                            <option value="alcohol" <?php echo ($edit_item['category'] ?? '') == 'alcohol' ? 'selected' : ''; ?>>Алкоголь</option>
                            <option value="snacks" <?php echo ($edit_item['category'] ?? '') == 'snacks' ? 'selected' : ''; ?>>Закуски</option>
                            <option value="desserts" <?php echo ($edit_item['category'] ?? '') == 'desserts' ? 'selected' : ''; ?>>Десерты</option>
                            <option value="drinks" <?php echo ($edit_item['category'] ?? '') == 'drinks' ? 'selected' : ''; ?>>Напитки</option>
                            <option value="games" <?php echo ($edit_item['category'] ?? '') == 'games' ? 'selected' : ''; ?>>Игры</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="itemDescription">
                        <i class="fas fa-align-left"></i> Описание:
                    </label>
                    <textarea id="itemDescription" class="form-control" rows="3"><?php echo $edit_item ? htmlspecialchars($edit_item['description']) : ''; ?></textarea>
                    <small class="form-text">Опишите позицию для гостей</small>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="itemPrice">
                            <i class="fas fa-money-bill-wave"></i> Цена (₽):
                        </label>
                        <input type="number" id="itemPrice" class="form-control" min="0" step="1" 
                               value="<?php echo $edit_item ? $edit_item['price'] : '0'; ?>" required>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="itemAvailability">
                            <i class="fas fa-check-circle"></i> Доступность:
                        </label>
                        <select id="itemAvailability" class="form-control">
                            <option value="1" <?php echo ($edit_item['is_available'] ?? 1) ? 'selected' : ''; ?>>Доступно</option>
                            <option value="0" <?php echo !($edit_item['is_available'] ?? 1) ? 'selected' : ''; ?>>Недоступно</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> <?php echo $is_edit ? 'Сохранить изменения' : 'Добавить позицию'; ?>
                    </button>
                    <a href="menu_items.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Отмена
                    </a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Стили для страницы меню -->
<style>
/* Стили для фильтров */
.filters {
    display: flex;
    gap: 15px;
    margin-bottom: 20px;
    padding: 15px;
    background: rgba(26, 26, 26, 0.6);
    border-radius: 8px;
    border: 1px solid rgba(212, 175, 55, 0.2);
    flex-wrap: wrap;
    align-items: center;
}

.filter-group {
    display: flex;
    align-items: center;
    gap: 10px;
}

.filter-group label {
    color: var(--accent);
    font-weight: 500;
    white-space: nowrap;
}

.filter-select, .filter-input {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(212, 175, 55, 0.3);
    border-radius: 5px;
    color: white;
    padding: 8px 12px;
    min-width: 150px;
}

.filter-select:focus, .filter-input:focus {
    outline: none;
    border-color: var(--secondary);
    background: rgba(255, 255, 255, 0.15);
}

/* Бейдж категории */
.category-badge {
    display: inline-block;
    padding: 5px 12px;
    border-radius: 15px;
    font-size: 0.85rem;
    font-weight: 600;
    text-align: center;
    min-width: 100px;
}

.category-alcohol {
    background: rgba(139, 0, 0, 0.2);
    color: #ff7f7f;
    border: 1px solid rgba(139, 0, 0, 0.5);
}

.category-snacks {
    background: rgba(255, 140, 0, 0.2);
    color: #ffa500;
    border: 1px solid rgba(255, 140, 0, 0.5);
}

.category-desserts {
    background: rgba(148, 0, 211, 0.2);
    color: #dda0dd;
    border: 1px solid rgba(148, 0, 211, 0.5);
}

.category-drinks {
    background: rgba(30, 144, 255, 0.2);
    color: #87cefa;
    border: 1px solid rgba(30, 144, 255, 0.5);
}

.category-games {
    background: rgba(199, 21, 133, 0.2);
    color: var(--secondary);
    border: 1px solid rgba(199, 21, 133, 0.5);
}

/* Ячейка описания */
.description-cell {
    max-width: 300px;
    color: var(--secondary-light);
    font-size: 0.9rem;
    line-height: 1.4;
}

/* Бейдж доступности */
.availability-badge {
    display: inline-block;
    padding: 5px 12px;
    border-radius: 15px;
    font-size: 0.85rem;
    font-weight: 600;
    text-align: center;
    min-width: 120px;
}

.availability-yes {
    background: rgba(0, 128, 0, 0.2);
    color: #90ee90;
    border: 1px solid rgba(0, 128, 0, 0.5);
}

.availability-no {
    background: rgba(255, 0, 0, 0.2);
    color: #ff7f7f;
    border: 1px solid rgba(255, 0, 0, 0.5);
}

/* Статистика меню */
.menu-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.stat-card.mini {
    background: rgba(26, 26, 26, 0.6);
    border-radius: 10px;
    padding: 15px;
    text-align: center;
    border: 1px solid rgba(212, 175, 55, 0.1);
}

.stat-card.mini h4 {
    color: var(--secondary);
    font-size: 0.9rem;
    margin-bottom: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
}

.stat-card.mini p {
    color: var(--accent);
    font-size: 1.5rem;
    font-weight: bold;
    margin: 0;
}

/* Форма */
.menu-form .form-group {
    margin-bottom: 20px;
}

.menu-form label {
    color: var(--accent);
    font-weight: 500;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.menu-form .form-control {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(212, 175, 55, 0.3);
    border-radius: 5px;
    color: white;
    padding: 10px 15px;
    font-size: 1rem;
    transition: all 0.3s;
}

.menu-form .form-control:focus {
    outline: none;
    border-color: var(--secondary);
    background: rgba(255, 255, 255, 0.15);
}

.menu-form .form-text {
    color: var(--secondary-light);
    font-size: 0.85rem;
    margin-top: 5px;
}

.menu-form .form-actions {
    display: flex;
    gap: 15px;
    margin-top: 30px;
}

/* Адаптивность */
@media (max-width: 768px) {
    .filters {
        flex-direction: column;
        align-items: stretch;
    }
    
    .filter-group {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .filter-select, .filter-input {
        width: 100%;
    }
    
    .description-cell {
        max-width: 200px;
    }
    
    .menu-form .form-row {
        flex-direction: column;
    }
    
    .menu-form .col-md-6 {
        flex: 0 0 100%;
        max-width: 100%;
    }
}
</style>

<script>
    
   document.addEventListener('DOMContentLoaded', function() {
    // Функция обновления страницы
    window.refreshMenu = function() {
        location.reload();
    };

    function applyFilters() {
        const categoryValue = filterCategory.value;
        const availabilityValue = filterAvailability.value;
        
        tableRows.forEach(row => {
            const rowCategory = row.getAttribute('data-category');
            const rowAvailability = row.getAttribute('data-available');
            
            let showRow = true;
            
            if (categoryValue && rowCategory !== categoryValue) {
                showRow = false;
            }
            
            if (availabilityValue && rowAvailability !== availabilityValue) {
                showRow = false;
            }
            
            row.style.display = showRow ? '' : 'none';
        });
        
        // Обновляем статистику
        updateStats();
    }
    
    if (filterCategory) filterCategory.addEventListener('change', applyFilters);
    if (filterAvailability) filterAvailability.addEventListener('change', applyFilters);
    
    // Функция обновления статистики
    function updateStats() {
        const visibleRows = Array.from(tableRows).filter(row => row.style.display !== 'none');
        const totalItems = visibleRows.length;
        
        const alcoholItems = visibleRows.filter(row => 
            row.getAttribute('data-category') === 'alcohol'
        ).length;
        
        const snackItems = visibleRows.filter(row => 
            row.getAttribute('data-category') === 'snacks'
        ).length;
        
        const availableItems = visibleRows.filter(row => 
            row.getAttribute('data-available') === 'available'
        ).length;
        
        // Обновляем элементы статистики
        const totalElement = document.getElementById('totalItems');
        const alcoholElement = document.getElementById('alcoholItems');
        const snackElement = document.getElementById('snackItems');
        const availableElement = document.getElementById('availableItems');
        
        if (totalElement) totalElement.textContent = totalItems;
        if (alcoholElement) alcoholElement.textContent = alcoholItems;
        if (snackElement) snackElement.textContent = snackItems;
        if (availableElement) availableElement.textContent = availableItems;
    }
    
    // Инициализация статистики
    updateStats();
    
    // Обработка формы
    const form = document.getElementById('menuItemForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Собираем данные формы
            const formData = {
                name: document.getElementById('itemName').value,
                category: document.getElementById('itemCategory').value,
                description: document.getElementById('itemDescription').value,
                price: document.getElementById('itemPrice').value,
                available: document.getElementById('itemAvailability').value
            };
            
            // Валидация
            if (!formData.name || !formData.category || !formData.price) {
                alert('Пожалуйста, заполните обязательные поля: Название, Категория, Цена');
                return;
            }
            
            // Сохраняем в демо-режиме
            alert('Позиция сохранена! (демо-режим)');
            window.location.href = 'menu_items.php?success=1';
        });
    }
    
    // Функция обновления страницы
    window.refreshMenu = function() {
        location.reload();
    };
    
      // Подсветка текущей страницы в меню
    const currentPage = 'menu_items.php';
    document.querySelectorAll('.nav-link').forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.style.backgroundColor = 'rgba(249, 166, 45, 0.2)';
            link.style.color = 'var(--accent)';
        }
    });
})
</script>

<?php 
ob_end_flush(); // Отправляем буфер вывода
require_once 'footer.php'; 
?>