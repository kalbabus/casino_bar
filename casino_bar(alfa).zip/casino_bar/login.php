<?php
// login.php
require_once 'config.php';

// Если уже авторизован, перенаправляем на главную
if (!isGuest()) {
    header('Location: index.php');
    exit;
}

// Обработка формы входа
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Демо-авторизация (в реальной системе проверяем в БД)
    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['user_id'] = 1;
        $_SESSION['role'] = 'admin';
        $_SESSION['first_name'] = 'Администратор';
        header('Location: index.php');
        exit;
    } elseif ($username === 'employee' && $password === 'emp123') {
        $_SESSION['user_id'] = 2;
        $_SESSION['role'] = 'employee';
        $_SESSION['first_name'] = 'Сотрудник';
        header('Location: index.php');
        exit;
    } else {
        $error = 'Неверное имя пользователя или пароль';
    }
}

// Демо-вход
if (isset($_GET['demo'])) {
    $_SESSION['user_id'] = 999;
    $_SESSION['role'] = 'guest';
    $_SESSION['first_name'] = 'Демо-Гость';
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход - Элитное Казино</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: linear-gradient(135deg, #0a0a0a, #1a1a1a);
            color: #F5F5F5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            width: 100%;
            max-width: 450px;
        }
        
        .login-card {
            background: rgba(26, 26, 26, 0.9);
            border-radius: 20px;
            padding: 40px;
            border: 2px solid #D4AF37;
            box-shadow: 0 20px 50px rgba(199, 21, 133, 0.3);
            text-align: center;
        }
        
        .logo {
            color: #D4AF37;
            font-size: 3rem;
            margin-bottom: 20px;
        }
        
        h1 {
            color: #D4AF37;
            font-family: 'Cinzel', serif;
            margin-bottom: 10px;
        }
        
        .subtitle {
            color: #888;
            margin-bottom: 30px;
            font-size: 1.1rem;
        }
        
        .form-group {
            margin-bottom: 25px;
            text-align: left;
        }
        
        label {
            display: block;
            color: #D4AF37;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .input-with-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #C71585;
        }
        
        input {
            width: 100%;
            padding: 15px 15px 15px 45px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(212, 175, 55, 0.3);
            border-radius: 8px;
            color: white;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        input:focus {
            outline: none;
            border-color: #C71585;
            background: rgba(255, 255, 255, 0.15);
        }
        
        .btn-login {
            width: 100%;
            padding: 15px;
            background: linear-gradient(45deg, #C71585, #8B0000);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
        }
        
        .btn-login:hover {
            background: linear-gradient(45deg, #8B0000, #C71585);
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(199, 21, 133, 0.3);
        }
        
        .btn-demo {
            display: block;
            width: 100%;
            padding: 15px;
            background: rgba(212, 175, 55, 0.2);
            color: #D4AF37;
            border: 1px solid #D4AF37;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            margin-bottom: 20px;
        }
        
        .btn-demo:hover {
            background: rgba(212, 175, 55, 0.4);
            transform: translateY(-3px);
        }
        
        .error {
            background: rgba(139, 0, 0, 0.2);
            border: 1px solid #8B0000;
            color: #FF7F7F;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .footer-links {
            margin-top: 30px;
            color: #888;
        }
        
        .footer-links a {
            color: #C71585;
            text-decoration: none;
        }
        
        .footer-links a:hover {
            color: #D4AF37;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="logo">
                <i class="fas fa-gem"></i>
            </div>
            <h1>Элитное Казино</h1>
            <p class="subtitle">Войдите в систему управления</p>
            
            <?php if ($error): ?>
            <div class="error">
                <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
            </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Имя пользователя</label>
                    <div class="input-with-icon">
                        <i class="fas fa-user"></i>
                        <input type="text" id="username" name="username" required placeholder="Введите имя пользователя">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Пароль</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" required placeholder="Введите пароль">
                    </div>
                </div>
                
                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Войти в систему
                </button>
            </form>
            
            <a href="?demo=1" class="btn-demo">
                <i class="fas fa-user-secret"></i> Войти как демо-гость
            </a>
            
            <div class="footer-links">
                <p>Тестовые учетные данные:</p>
                <p>Админ: admin / admin123</p>
                <p>Сотрудник: employee / emp123</p>
            </div>
        </div>
    </div>
</body>
</html>