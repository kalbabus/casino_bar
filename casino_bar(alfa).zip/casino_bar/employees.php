<?php
require_once 'config.php';
require_once 'header.php';

// Проверка авторизации
if (isGuest()) {
    header('Location: login.php');
    exit;
}
?>

<div class="container">
    <h1><i class="fas fa-users"></i> Управление сотрудниками</h1>
    
    <div class="card">
        <div class="card-header">
            <h3>Список сотрудников</h3>
            <a href="?add" class="btn btn-primary">
                <i class="fas fa-plus"></i> Добавить сотрудника
            </a>
        </div>
        
        <div class="card-body">
            <?php
            try {
                $stmt = $pdo->query("SELECT * FROM employees ORDER BY id DESC");
                if ($stmt->rowCount() > 0):
            ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Имя</th>
                        <th>Фамилия</th>
                        <th>Должность</th>
                        <th>Телефон</th>
                        <th>Дата найма</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $stmt->fetch()): ?>
                    <tr>
                        <td><?php echo escape($row['id']); ?></td>
                        <td><?php echo escape($row['first_name']); ?></td>
                        <td><?php echo escape($row['last_name']); ?></td>
                        <td><?php echo escape($row['position']); ?></td>
                        <td><?php echo escape($row['phone']); ?></td>
                        <td><?php echo date('d.m.Y', strtotime($row['hire_date'])); ?></td>
                        <td>
                            <a href="?edit=<?php echo $row['id']; ?>" class="btn-action btn-edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="?delete=<?php echo $row['id']; ?>" class="btn-action btn-delete" onclick="return confirm('Удалить сотрудника?')">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="no-data">
                <i class="fas fa-users" style="font-size: 3em; opacity: 0.3;"></i>
                <p>Нет данных о сотрудниках</p>
                <a href="?add" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Добавить первого сотрудника
                </a>
            </div>
            <?php endif; ?>
            <?php } catch (Exception $e) { ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-triangle"></i> Ошибка загрузки данных: <?php echo $e->getMessage(); ?>
            </div>
            <?php } ?>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>