<?php
require_once 'config.php';
require_once 'header.php';
?>

<div class="container">
    <h1><i class="fas fa-user-tie"></i> Гости казино</h1>
    
    <div class="card">
        <div class="card-header">
            <h3>Список гостей</h3>
            <?php if (!isGuest()): ?>
            <a href="?add" class="btn btn-primary">
                <i class="fas fa-plus"></i> Добавить гостя
            </a>
            <?php endif; ?>
        </div>
        
        <div class="card-body">
            <?php
            try {
                $stmt = $pdo->query("SELECT * FROM guests ORDER BY total_spent DESC");
                if ($stmt->rowCount() > 0):
            ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Имя</th>
                        <th>Фамилия</th>
                        <th>Телефон</th>
                        <th>Посещений</th>
                        <th>Потрачено</th>
                        <th>Статус VIP</th>
                        <?php if (!isGuest()): ?>
                        <th>Действия</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $stmt->fetch()): 
                        $vipLevel = $row['total_spent'] > 50000 ? 'VIP Diamond' : 
                                   ($row['total_spent'] > 20000 ? 'VIP Gold' : 
                                   ($row['total_spent'] > 10000 ? 'VIP Silver' : 'Обычный'));
                    ?>
                    <tr>
                        <td><?php echo escape($row['id']); ?></td>
                        <td><strong><?php echo escape($row['first_name']); ?></strong></td>
                        <td><?php echo escape($row['last_name']); ?></td>
                        <td><?php echo escape($row['phone']); ?></td>
                        <td><?php echo escape($row['visits_count']); ?></td>
                        <td class="amount-cell"><?php echo number_format($row['total_spent'], 0); ?> ₽</td>
                        <td>
                            <span class="vip-badge vip-<?php echo strtolower(str_replace(' ', '-', $vipLevel)); ?>">
                                <?php echo $vipLevel; ?>
                            </span>
                        </td>
                        <?php if (!isGuest()): ?>
                        <td>
                            <a href="?edit=<?php echo $row['id']; ?>" class="btn-action btn-edit">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="no-data">
                <i class="fas fa-user-tie" style="font-size: 3em; opacity: 0.3;"></i>
                <p>Нет данных о гостях</p>
            </div>
            <?php endif; ?>
            <?php } catch (Exception $e) { ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-triangle"></i> Ошибка загрузки данных
            </div>
            <?php } ?>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>