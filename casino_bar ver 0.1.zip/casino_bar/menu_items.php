<?php
// menu_items.php - ПОЛУЧЕНИЕ ДАННЫХ ИЗ БАЗЫ ДАННЫХ

// Включаем буферизацию вывода
ob_start();

require_once 'config.php';
require_once 'header.php';

// Проверка авторизации
if (isGuest()) {
    ob_end_clean();
    header('Location: login.php');
    exit;
}

// Режим отладки - показываем ошибки БД
$demo_mode = false;
$db_error = null;

// Получаем данные из базы данных
$menuItems = [];
$categories = [];

try {
    // Проверяем существование таблицы menu_items
    $checkTable = $pdo->query("SHOW TABLES LIKE 'menu_items'");
    if ($checkTable->rowCount() > 0) {
        // Получаем все позиции меню
        $stmt = $pdo->query("SELECT * FROM menu_items ORDER BY category, name");
        $menuItems = $stmt->fetchAll();
        
        // Получаем уникальные категории для фильтра
        $catStmt = $pdo->query("SELECT DISTINCT category FROM menu_items ORDER BY category");
        $categories = $catStmt->fetchAll(PDO::FETCH_COLUMN);
    } else {
        $db_error = "Таблица 'menu_items' не найдена в базе данных";
    }
} catch (Exception $e) {
    $db_error = "Ошибка базы данных: " . $e->getMessage();
    $demo_mode = true; // Переключаемся в демо-режим при ошибке
}

// Демо-данные на случай отсутствия БД
if ($demo_mode && empty($menuItems)) {
    $menuItems = [
        [
            'id' => 1,
            'name' => 'Пиво Балтика №7',
            'category' => 'alcohol',
            'description' => 'Пиво Балтика №7, 0.5л',
            'price' => 200,
            'is_available' => 1
        ],
        [
            'id' => 2,
            'name' => 'Виски Джеймсон',
            'category' => 'alcohol',
            'description' => 'Jameson Irish Whiskey, 40мл',
            'price' => 350,
            'is_available' => 1
        ],
        [
            'id' => 3,
            'name' => 'Картофель фри',
            'category' => 'snacks',
            'description' => 'Хрустящий картофель фри с соусом',
            'price' => 250,
            'is_available' => 1
        ]
    ];
    $categories = ['alcohol', 'snacks'];
}

// Массив для названий категорий на русском
$categoryNames = [
    'alcohol' => '🍷 Алкоголь',
    'beer' => '🍺 Пиво',
    'wine' => '🍷 Вино',
    'spirits' => '🥃 Крепкий алкоголь',
    'cocktails' => '🍸 Коктейли',
    'soft' => '🧃 Безалкогольные',
    'juices' => '🧃 Соки',
    'water' => '💧 Вода',
    'soda' => '🥤 Газировка',
    'hot' => '☕ Горячие напитки',
    'coffee' => '☕ Кофе',
    'tea' => '🍵 Чай',
    'appetizers' => '🥗 Закуски',
    'hot_dishes' => '🍲 Горячие блюда',
    'desserts' => '🍰 Десерты',
    'snacks' => '🍿 Снеки',
    'salads' => '🥗 Салаты',
    'soups' => '🍜 Супы',
    'pasta' => '🍝 Паста',
    'pizza' => '🍕 Пицца',
    'burgers' => '🍔 Бургеры',
    'fish' => '🐟 Рыба',
    'meat' => '🥩 Мясо',
    'garnish' => '🍚 Гарниры',
    'breakfast' => '🍳 Завтраки'
];

// Обработка добавления/редактирования
$message = '';
if (isset($_GET['success'])) {
    $message = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Изменения сохранены!</div>';
}
?>

<div class="container">
    <h1><i class="fas fa-utensils"></i> Меню ресторана и бара</h1>
    
    <?php echo $message; ?>
    
    <?php if ($db_error): ?>
    <div class="alert alert-error">
        <i class="fas fa-exclamation-triangle"></i> <?php echo $db_error; ?>
        <br><small>Показаны демо-данные</small>
    </div>
    <?php endif; ?>
    
    <?php if ($demo_mode && !$db_error): ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i> Режим демонстрации: используются тестовые данные
    </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Все позиции меню (<?php echo count($menuItems); ?>)</h3>
            <div class="action-buttons">
                <a href="?add" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Добавить позицию
                </a>
                <button class="btn btn-secondary" onclick="refreshMenu()">
                    <i class="fas fa-sync-alt"></i> Обновить
                </button>
            </div>
        </div>
        
        <div class="card-body">
            <!-- Фильтры по категориям -->
            <div class="filters">
                <div class="filter-group">
                    <label for="filterCategory"><i class="fas fa-filter"></i> Категория:</label>
                    <select id="filterCategory" class="filter-select">
                        <option value="">Все категории</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo htmlspecialchars($cat); ?>">
                            <?php echo $categoryNames[$cat] ?? ucfirst(str_replace('_', ' ', $cat)); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="filterAvailability"><i class="fas fa-check-circle"></i> Доступность:</label>
                    <select id="filterAvailability" class="filter-select">
                        <option value="">Все</option>
                        <option value="available">✅ Доступно</option>
                        <option value="unavailable">❌ Недоступно</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="searchInput"><i class="fas fa-search"></i> Поиск:</label>
                    <input type="text" id="searchInput" class="filter-input" placeholder="Название или описание...">
                </div>
            </div>
            
            <!-- Статистика по категориям -->
            <div class="category-stats">
                <?php
                $categoryCounts = [];
                foreach ($menuItems as $item) {
                    $cat = $item['category'];
                    if (!isset($categoryCounts[$cat])) {
                        $categoryCounts[$cat] = 0;
                    }
                    $categoryCounts[$cat]++;
                }
                
                foreach ($categoryCounts as $cat => $count):
                ?>
                <span class="category-stat-badge">
                    <?php echo $categoryNames[$cat] ?? ucfirst($cat); ?>: <strong><?php echo $count; ?></strong>
                </span>
                <?php endforeach; ?>
            </div>
            
            <!-- Таблица меню -->
            <div class="table-responsive">
                <table class="data-table" id="menuTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Название</th>
                            <th>Категория</th>
                            <th>Описание</th>
                            <th>Цена</th>
                            <th>Доступно</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($menuItems as $item): 
                            $categoryDisplay = $categoryNames[$item['category']] ?? ucfirst(str_replace('_', ' ', $item['category']));
                        ?>
                        <tr data-category="<?php echo htmlspecialchars($item['category']); ?>" 
                            data-available="<?php echo $item['is_available'] ? 'available' : 'unavailable'; ?>"
                            data-name="<?php echo htmlspecialchars(strtolower($item['name'])); ?>"
                            data-description="<?php echo htmlspecialchars(strtolower($item['description'] ?? '')); ?>">
                            <td><?php echo $item['id']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($item['name']); ?></strong>
                            </td>
                            <td>
                                <span class="category-badge category-<?php echo htmlspecialchars($item['category']); ?>">
                                    <?php echo $categoryDisplay; ?>
                                </span>
                            </td>
                            <td class="description-cell">
                                <?php echo htmlspecialchars($item['description'] ?? 'Нет описания'); ?>
                            </td>
                            <td class="amount-cell">
                                <span class="price-value"><?php echo number_format($item['price'], 0); ?></span> ₽
                            </td>
                            <td>
                                <span class="availability-badge availability-<?php echo $item['is_available'] ? 'yes' : 'no'; ?>">
                                    <?php echo $item['is_available'] ? '✅ Доступно' : '❌ Недоступно'; ?>
                                </span>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <a href="?edit=<?php echo $item['id']; ?>" 
                                       class="btn-action btn-edit" title="Редактировать">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete=<?php echo $item['id']; ?>" 
                                       class="btn-action btn-delete" 
                                       title="Удалить"
                                       onclick="return confirm('Удалить позицию \'<?php echo addslashes($item['name']); ?>\'?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Форма добавления/редактирования -->
    <?php if (isset($_GET['add']) || isset($_GET['edit'])): 
        $is_edit = isset($_GET['edit']);
        $item_id = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
        
        // Находим редактируемую позицию
        $edit_item = null;
        if ($is_edit && $item_id > 0) {
            foreach ($menuItems as $item) {
                if ($item['id'] == $item_id) {
                    $edit_item = $item;
                    break;
                }
            }
        }
    ?>
    <div class="card mt-4">
        <div class="card-header">
            <h3>
                <i class="fas <?php echo $is_edit ? 'fa-edit' : 'fa-plus-circle'; ?>"></i>
                <?php echo $is_edit ? 'Редактирование позиции' : 'Добавление новой позиции'; ?>
            </h3>
        </div>
        <div class="card-body">
            <form id="menuItemForm" class="menu-form" method="POST" action="save_menu_item.php">
                <input type="hidden" name="id" value="<?php echo $edit_item['id'] ?? ''; ?>">
                
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="itemName">
                            <i class="fas fa-tag"></i> Название позиции:
                        </label>
                        <input type="text" id="itemName" name="name" class="form-control" 
                               value="<?php echo $edit_item ? htmlspecialchars($edit_item['name']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="itemCategory">
                            <i class="fas fa-list"></i> Категория:
                        </label>
                        <select id="itemCategory" name="category" class="form-control" required>
                            <option value="">Выберите категорию</option>
                            <?php foreach ($categoryNames as $catKey => $catName): ?>
                            <option value="<?php echo $catKey; ?>" 
                                <?php echo ($edit_item['category'] ?? '') == $catKey ? 'selected' : ''; ?>>
                                <?php echo $catName; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="itemDescription">
                        <i class="fas fa-align-left"></i> Описание:
                    </label>
                    <textarea id="itemDescription" name="description" class="form-control" rows="3"><?php echo $edit_item ? htmlspecialchars($edit_item['description']) : ''; ?></textarea>
                    <small class="form-text">Опишите позицию для гостей</small>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="itemPrice">
                            <i class="fas fa-money-bill-wave"></i> Цена (₽):
                        </label>
                        <input type="number" id="itemPrice" name="price" class="form-control" min="0" step="1" 
                               value="<?php echo $edit_item ? $edit_item['price'] : '0'; ?>" required>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="itemAvailability">
                            <i class="fas fa-check-circle"></i> Доступность:
                        </label>
                        <select id="itemAvailability" name="is_available" class="form-control">
                            <option value="1" <?php echo ($edit_item['is_available'] ?? 1) ? 'selected' : ''; ?>>Доступно</option>
                            <option value="0" <?php echo !($edit_item['is_available'] ?? 1) ? 'selected' : ''; ?>>Недоступно</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> <?php echo $is_edit ? 'Сохранить изменения' : 'Добавить позицию'; ?>
                    </button>
                    <a href="menu_items.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Отмена
                    </a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
/* Стили для фильтров */
.filters {
    display: flex;
    gap: 15px;
    margin-bottom: 20px;
    padding: 15px;
    background: rgba(26, 26, 26, 0.6);
    border-radius: 8px;
    border: 1px solid rgba(212, 175, 55, 0.2);
    flex-wrap: wrap;
    align-items: center;
}

.filter-group {
    display: flex;
    align-items: center;
    gap: 10px;
    flex: 1 1 200px;
}

.filter-group label {
    color: var(--accent);
    font-weight: 500;
    white-space: nowrap;
}

.filter-select, .filter-input {
    width: 100%;
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(212, 175, 55, 0.3);
    border-radius: 5px;
    color: white;
    padding: 8px 12px;
}

.filter-select:focus, .filter-input:focus {
    outline: none;
    border-color: var(--secondary);
    background: rgba(255, 255, 255, 0.15);
}

/* Статистика по категориям */
.category-stats {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 20px;
    padding: 10px;
    background: rgba(0, 0, 0, 0.2);
    border-radius: 8px;
}

.category-stat-badge {
    background: rgba(212, 175, 55, 0.1);
    border: 1px solid rgba(212, 175, 55, 0.3);
    border-radius: 20px;
    padding: 5px 12px;
    font-size: 0.85rem;
    color: var(--secondary-light);
}

.category-stat-badge strong {
    color: var(--accent);
}

/* Бейдж категории */
.category-badge {
    display: inline-block;
    padding: 5px 12px;
    border-radius: 15px;
    font-size: 0.85rem;
    font-weight: 600;
    text-align: center;
    white-space: nowrap;
}

/* Динамические цвета для категорий */
.category-alcohol, .category-spirits, .category-beer, .category-wine {
    background: rgba(139, 0, 0, 0.2);
    color: #ff7f7f;
    border: 1px solid rgba(139, 0, 0, 0.5);
}

.category-cocktails {
    background: rgba(199, 21, 133, 0.2);
    color: #ff69b4;
    border: 1px solid rgba(199, 21, 133, 0.5);
}

.category-soft, .category-juices, .category-water, .category-soda {
    background: rgba(30, 144, 255, 0.2);
    color: #87cefa;
    border: 1px solid rgba(30, 144, 255, 0.5);
}

.category-hot, .category-coffee, .category-tea {
    background: rgba(255, 140, 0, 0.2);
    color: #ffb347;
    border: 1px solid rgba(255, 140, 0, 0.5);
}

.category-appetizers, .category-snacks {
    background: rgba(255, 215, 0, 0.2);
    color: #ffd700;
    border: 1px solid rgba(255, 215, 0, 0.5);
}

.category-hot_dishes, .category-pasta, .category-pizza, .category-burgers {
    background: rgba(165, 42, 42, 0.2);
    color: #cd5c5c;
    border: 1px solid rgba(165, 42, 42, 0.5);
}

.category-desserts {
    background: rgba(148, 0, 211, 0.2);
    color: #dda0dd;
    border: 1px solid rgba(148, 0, 211, 0.5);
}

.category-salads {
    background: rgba(0, 128, 0, 0.2);
    color: #90ee90;
    border: 1px solid rgba(0, 128, 0, 0.5);
}

/* Ячейка описания */
.description-cell {
    max-width: 300px;
    color: var(--secondary-light);
    font-size: 0.9rem;
    line-height: 1.4;
}

/* Бейдж доступности */
.availability-badge {
    display: inline-block;
    padding: 5px 12px;
    border-radius: 15px;
    font-size: 0.85rem;
    font-weight: 600;
    text-align: center;
    white-space: nowrap;
}

.availability-yes {
    background: rgba(0, 128, 0, 0.2);
    color: #90ee90;
    border: 1px solid rgba(0, 128, 0, 0.5);
}

.availability-no {
    background: rgba(255, 0, 0, 0.2);
    color: #ff7f7f;
    border: 1px solid rgba(255, 0, 0, 0.5);
}

/* Форма */
.menu-form .form-group {
    margin-bottom: 20px;
}

.menu-form label {
    color: var(--accent);
    font-weight: 500;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.menu-form .form-control {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(212, 175, 55, 0.3);
    border-radius: 5px;
    color: white;
    padding: 10px 15px;
    font-size: 1rem;
    transition: all 0.3s;
}

.menu-form .form-control:focus {
    outline: none;
    border-color: var(--secondary);
    background: rgba(255, 255, 255, 0.15);
}

.menu-form .form-text {
    color: var(--secondary-light);
    font-size: 0.85rem;
    margin-top: 5px;
}

.menu-form .form-actions {
    display: flex;
    gap: 15px;
    margin-top: 30px;
}

/* Адаптивность */
@media (max-width: 768px) {
    .filters {
        flex-direction: column;
    }
    
    .filter-group {
        width: 100%;
    }
    
    .description-cell {
        max-width: 150px;
    }
    
    .menu-form .form-row {
        flex-direction: column;
    }
    
    .category-stats {
        max-height: 200px;
        overflow-y: auto;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var filterCategory = document.getElementById('filterCategory');
    var filterAvailability = document.getElementById('filterAvailability');
    var searchInput = document.getElementById('searchInput');
    var tableRows = document.querySelectorAll('#menuTable tbody tr');
    
    // Функция обновления страницы
    window.refreshMenu = function() {
        location.reload();
    };

    function applyFilters() {
        var categoryValue = filterCategory ? filterCategory.value : '';
        var availabilityValue = filterAvailability ? filterAvailability.value : '';
        var searchValue = searchInput ? searchInput.value.toLowerCase() : '';
        
        for (var i = 0; i < tableRows.length; i++) {
            var row = tableRows[i];
            var rowCategory = row.getAttribute('data-category');
            var rowAvailability = row.getAttribute('data-available');
            var rowName = row.getAttribute('data-name') || '';
            var rowDescription = row.getAttribute('data-description') || '';
            
            var showRow = true;
            
            // Фильтр по категории
            if (categoryValue && rowCategory !== categoryValue) {
                showRow = false;
            }
            
            // Фильтр по доступности
            if (availabilityValue && rowAvailability !== availabilityValue) {
                showRow = false;
            }
            
            // Поиск по названию и описанию
            if (searchValue && rowName.indexOf(searchValue) === -1 && rowDescription.indexOf(searchValue) === -1) {
                showRow = false;
            }
            
            row.style.display = showRow ? '' : 'none';
        }
    }
    
    // Добавляем обработчики событий
    if (filterCategory) filterCategory.addEventListener('change', applyFilters);
    if (filterAvailability) filterAvailability.addEventListener('change', applyFilters);
    if (searchInput) searchInput.addEventListener('keyup', applyFilters);
    
    // Обработка формы (если есть)
    var form = document.getElementById('menuItemForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Собираем данные формы
            var formData = {
                name: document.getElementById('itemName').value,
                category: document.getElementById('itemCategory').value,
                description: document.getElementById('itemDescription').value,
                price: document.getElementById('itemPrice').value,
                available: document.getElementById('itemAvailability').value
            };
            
            // Валидация
            if (!formData.name || !formData.category || !formData.price) {
                alert('Пожалуйста, заполните обязательные поля: Название, Категория, Цена');
                return;
            }
            
            // Отправляем данные
            alert('Позиция сохранена! (В реальном проекте данные отправятся в БД)');
            window.location.href = 'menu_items.php?success=1';
        });
    }
});
</script>

<?php 
ob_end_flush();
require_once 'footer.php'; 
?>