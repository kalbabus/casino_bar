<?php
require_once 'config.php';
require_once 'header.php';

// Проверка авторизации
if (isGuest()) {
    header('Location: login.php');
    exit;
}
?>

<div class="container">
    <h1><i class="fas fa-clock"></i> Управление сменами</h1>
    
    <div class="card">
        <div class="card-header">
            <h3>Список смен</h3>
            <a href="?new" class="btn btn-primary">
                <i class="fas fa-plus"></i> Открыть смену
            </a>
        </div>
        
        <div class="card-body">
            <?php
            try {
                $stmt = $pdo->query("SELECT s.*, e.first_name, e.last_name 
                                    FROM shifts s 
                                    JOIN employees e ON s.employee_id = e.id 
                                    ORDER BY s.start_time DESC");
                if ($stmt->rowCount() > 0):
            ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Сотрудник</th>
                        <th>Начало</th>
                        <th>Конец</th>
                        <th>Начальная касса</th>
                        <th>Конечная касса</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $stmt->fetch()): ?>
                    <tr>
                        <td><?php echo escape($row['id']); ?></td>
                        <td><?php echo escape($row['first_name'] . ' ' . $row['last_name']); ?></td>
                        <td><?php echo date('d.m.Y H:i', strtotime($row['start_time'])); ?></td>
                        <td>
                            <?php if ($row['end_time']): ?>
                                <?php echo date('d.m.Y H:i', strtotime($row['end_time'])); ?>
                            <?php else: ?>
                                <em>Не завершена</em>
                            <?php endif; ?>
                        </td>
                        <td class="amount-cell"><?php echo number_format($row['initial_cash'], 0); ?> ₽</td>
                        <td class="amount-cell">
                            <?php if ($row['final_cash']): ?>
                                <?php echo number_format($row['final_cash'], 0); ?> ₽
                            <?php else: ?>
                                <em>Не указана</em>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="status status-<?php echo strtolower($row['status']); ?>">
                                <?php echo escape($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($row['status'] == 'active'): ?>
                                <a href="?close=<?php echo $row['id']; ?>" class="btn-action btn-close" title="Закрыть смену">
                                    <i class="fas fa-stop"></i>
                                </a>
                            <?php endif; ?>
                            <a href="?edit=<?php echo $row['id']; ?>" class="btn-action btn-edit" title="Редактировать">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="no-data">
                <i class="fas fa-clock" style="font-size: 3em; opacity: 0.3;"></i>
                <p>Нет данных о сменах</p>
                <a href="?new" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Открыть первую смену
                </a>
            </div>
            <?php endif; ?>
            <?php } catch (Exception $e) { ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-triangle"></i> Ошибка загрузки данных
            </div>
            <?php } ?>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>