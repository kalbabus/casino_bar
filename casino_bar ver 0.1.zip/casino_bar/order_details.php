<?php
// order_details.php - исправленная версия

// Включаем буферизацию вывода для предотвращения ошибок с заголовками
ob_start();

require_once 'config.php';
require_once 'header.php';

// Проверка авторизации
if (isGuest()) {
    ob_end_clean(); // Очищаем буфер
    header('Location: login.php');
    exit;
}

// Получение ID заказа из URL
$order_id = $_GET['order_id'] ?? 0;

if (!$order_id) {
    ob_end_clean(); // Очищаем буфер
    header('Location: orders.php');
    exit;
}

// Тестовые данные (если БД не работает)
$demo_mode = true; // Установите false, если БД работает

if ($demo_mode) {
    // Демо-данные
    $order = [
        'id' => $order_id,
        'guest_id' => 1,
        'first_name' => 'Иван',
        'last_name' => 'Петров',
        'phone' => '+7 (999) 123-45-67',
        'order_type' => 'game',
        'total_amount' => 15000,
        'status' => 'completed',
        'order_time' => '2024-01-15 20:30:00',
        'notes' => 'Игра в рулетку, ставка на красное'
    ];
    
    $details = [
        [
            'menu_item_id' => 1,
            'name' => 'Премиум рулетка',
            'price' => 5000,
            'quantity' => 3
        ]
    ];
} else {
    // Реальные данные из БД
    try {
        // Получаем информацию о заказе
        $stmt = $pdo->prepare("SELECT o.*, g.first_name, g.last_name, g.phone 
                              FROM orders o 
                              LEFT JOIN guests g ON o.guest_id = g.id 
                              WHERE o.id = ?");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch();
        
        if (!$order) {
            ob_end_clean(); // Очищаем буфер
            header('Location: orders.php');
            exit;
        }
        
        // Получаем детали заказа
        $stmt = $pdo->prepare("SELECT od.*, mi.name, mi.price 
                              FROM order_details od 
                              JOIN menu_items mi ON od.menu_item_id = mi.id 
                              WHERE od.order_id = ?");
        $stmt->execute([$order_id]);
        $details = $stmt->fetchAll();
    } catch (Exception $e) {
        // Если ошибка БД, переходим в демо-режим
        $demo_mode = true;
        $order = [
            'id' => $order_id,
            'guest_id' => 1,
            'first_name' => 'Иван',
            'last_name' => 'Петров',
            'phone' => '+7 (999) 123-45-67',
            'order_type' => 'game',
            'total_amount' => 15000,
            'status' => 'completed',
            'order_time' => '2024-01-15 20:30:00',
            'notes' => 'Игра в рулетку, ставка на красное'
        ];
        $details = [
            [
                'menu_item_id' => 1,
                'name' => 'Премиум рулетка',
                'price' => 5000,
                'quantity' => 3
            ]
        ];
    }
}

// Получаем информацию для отображения
$order_type_text = $order['order_type'] == 'game' ? '🎰 Игра' : '🍸 Бар';
$status_class = strtolower($order['status'] ?? 'pending');
$status_text = [
    'pending' => 'В ожидании',
    'completed' => 'Завершен',
    'cancelled' => 'Отменен'
];
?>

<div class="container">
    <h1><i class="fas fa-list-alt"></i> Детали заказа #<?php echo $order_id; ?></h1>
    
    <?php if ($demo_mode): ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i> Режим демонстрации: используются тестовые данные
    </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header">
            <h3>Информация о заказе</h3>
            <div class="action-buttons">
                <a href="orders.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Назад к заказам
                </a>
                <a href="javascript:window.print()" class="btn btn-primary">
                    <i class="fas fa-print"></i> Печать
                </a>
            </div>
        </div>
        
        <div class="card-body">
            <!-- Основная информация -->
            <div class="order-summary">
                <div class="summary-row">
                    <div class="summary-col">
                        <h4><i class="fas fa-user-tie"></i> Информация о госте</h4>
                        <div class="info-item">
                            <span class="info-label">Гость:</span>
                            <span class="info-value">
                                <?php if ($order['guest_id']): ?>
                                    <strong><?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></strong>
                                    <div class="info-sub">
                                        <i class="fas fa-phone"></i> <?php echo htmlspecialchars($order['phone'] ?? 'Не указан'); ?>
                                    </div>
                                <?php else: ?>
                                    <em>Гость (без регистрации)</em>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="summary-col">
                        <h4><i class="fas fa-info-circle"></i> Детали заказа</h4>
                        <div class="info-item">
                            <span class="info-label">Тип:</span>
                            <span class="info-value">
                                <span class="order-type-badge order-type-<?php echo $order['order_type']; ?>">
                                    <?php echo $order_type_text; ?>
                                </span>
                            </span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Дата и время:</span>
                            <span class="info-value">
                                <?php echo date('d.m.Y H:i:s', strtotime($order['order_time'])); ?>
                            </span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Статус:</span>
                            <span class="info-value">
                                <span class="status status-<?php echo $status_class; ?>">
                                    <?php echo $status_text[$status_class] ?? ucfirst($status_class); ?>
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="summary-row">
                    <div class="summary-col">
                        <h4><i class="fas fa-file-alt"></i> Примечания</h4>
                        <div class="notes-box">
                            <?php echo !empty($order['notes']) ? nl2br(htmlspecialchars($order['notes'])) : 'Нет примечаний'; ?>
                        </div>
                    </div>
                    
                    <div class="summary-col">
                        <h4><i class="fas fa-money-bill-wave"></i> Финансовая информация</h4>
                        <div class="financial-info">
                            <div class="total-amount">
                                <span class="total-label">Общая сумма:</span>
                                <span class="total-value"><?php echo number_format($order['total_amount'], 0); ?> ₽</span>
                            </div>
                            <?php if ($order['order_type'] == 'game'): ?>
                            <div class="game-info">
                                <small><i class="fas fa-dice"></i> Игровой заказ</small>
                            </div>
                            <?php else: ?>
                            <div class="bar-info">
                                <small><i class="fas fa-champagne-glasses"></i> Барный заказ</small>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Состав заказа -->
            <div class="order-composition">
                <h3><i class="fas fa-shopping-cart"></i> Состав заказа</h3>
                
                <?php if (!empty($details)): ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Позиция</th>
                                <th>Цена за единицу</th>
                                <th>Количество</th>
                                <th>Сумма</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total = 0;
                            foreach ($details as $index => $item): 
                                $item_total = $item['price'] * $item['quantity'];
                                $total += $item_total;
                            ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($item['name']); ?></strong>
                                    <?php if (!empty($item['description'])): ?>
                                        <div class="item-description">
                                            <?php echo htmlspecialchars($item['description']); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="amount-cell"><?php echo number_format($item['price'], 0); ?> ₽</td>
                                <td><?php echo $item['quantity']; ?> шт.</td>
                                <td class="amount-cell">
                                    <strong><?php echo number_format($item_total, 0); ?> ₽</strong>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-right">
                                    <strong>Итого:</strong>
                                </td>
                                <td class="amount-cell total-row">
                                    <strong><?php echo number_format($total, 0); ?> ₽</strong>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <?php else: ?>
                <div class="no-items">
                    <i class="fas fa-box-open"></i>
                    <p>Нет информации о составе заказа</p>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Дополнительные действия -->
            <div class="order-actions">
                <div class="action-group">
                    <h4><i class="fas fa-cogs"></i> Действия с заказом</h4>
                    <div class="action-buttons">
                        <?php if ($order['status'] == 'pending'): ?>
                            <button class="btn btn-success" onclick="completeOrder(<?php echo $order_id; ?>)">
                                <i class="fas fa-check-circle"></i> Завершить заказ
                            </button>
                            <button class="btn btn-danger" onclick="cancelOrder(<?php echo $order_id; ?>)">
                                <i class="fas fa-times-circle"></i> Отменить заказ
                            </button>
                        <?php elseif ($order['status'] == 'completed'): ?>
                            <button class="btn btn-warning" onclick="reopenOrder(<?php echo $order_id; ?>)">
                                <i class="fas fa-redo"></i> Переоткрыть заказ
                            </button>
                        <?php endif; ?>
                        <a href="?edit=<?php echo $order_id; ?>" class="btn btn-primary">
                            <i class="fas fa-edit"></i> Редактировать
                        </a>
                        <button class="btn btn-info" onclick="printReceipt(<?php echo $order_id; ?>)">
                            <i class="fas fa-receipt"></i> Печать чека
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Стили для деталей заказа */
.alert {
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
}

.alert-info {
    background: rgba(23, 162, 184, 0.2);
    border: 1px solid rgba(23, 162, 184, 0.5);
    color: #5bc0de;
}

.order-summary {
    background: rgba(26, 26, 26, 0.6);
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 30px;
    border: 1px solid rgba(212, 175, 55, 0.2);
}

.summary-row {
    display: flex;
    gap: 30px;
    margin-bottom: 20px;
}

.summary-row:last-child {
    margin-bottom: 0;
}

.summary-col {
    flex: 1;
}

.summary-col h4 {
    color: var(--accent);
    margin-bottom: 15px;
    font-size: 1.2rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-item {
    display: flex;
    margin-bottom: 10px;
    padding-bottom: 10px;
    border-bottom: 1px dashed rgba(255, 255, 255, 0.1);
}

.info-item:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.info-label {
    width: 150px;
    color: var(--secondary-light);
    font-weight: 500;
}

.info-value {
    flex: 1;
}

.info-sub {
    font-size: 0.9rem;
    color: var(--secondary-light);
    margin-top: 5px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.order-type-badge {
    display: inline-block;
    padding: 5px 12px;
    border-radius: 15px;
    font-size: 0.9rem;
    font-weight: 600;
}

.order-type-bar {
    background: rgba(0, 128, 0, 0.2);
    color: #90EE90;
    border: 1px solid rgba(0, 128, 0, 0.5);
}

.order-type-game {
    background: rgba(199, 21, 133, 0.2);
    color: var(--secondary);
    border: 1px solid rgba(199, 21, 133, 0.5);
}

.notes-box {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(212, 175, 55, 0.2);
    border-radius: 8px;
    padding: 15px;
    min-height: 100px;
    color: var(--secondary-light);
    line-height: 1.6;
}

.financial-info {
    padding: 15px;
    background: rgba(26, 26, 26, 0.8);
    border-radius: 8px;
    border: 1px solid rgba(212, 175, 55, 0.1);
}

.total-amount {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.total-label {
    color: var(--secondary-light);
    font-size: 1.1rem;
}

.total-value {
    color: var(--accent);
    font-size: 1.8rem;
    font-weight: bold;
}

.order-composition {
    margin-top: 30px;
}

.order-composition h3 {
    color: var(--accent);
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.table-responsive {
    overflow-x: auto;
}

.item-description {
    font-size: 0.9rem;
    color: var(--secondary-light);
    margin-top: 5px;
    font-style: italic;
}

.total-row {
    background: rgba(212, 175, 55, 0.1);
    font-size: 1.2rem;
}

.no-items {
    text-align: center;
    padding: 40px 20px;
    background: rgba(26, 26, 26, 0.6);
    border-radius: 10px;
    border: 1px dashed rgba(212, 175, 55, 0.3);
}

.no-items i {
    font-size: 3em;
    color: var(--accent);
    opacity: 0.5;
    margin-bottom: 15px;
}

.no-items p {
    color: var(--secondary-light);
    font-size: 1.1rem;
}

.order-actions {
    margin-top: 30px;
    padding: 20px;
    background: rgba(26, 26, 26, 0.6);
    border-radius: 10px;
    border: 1px solid rgba(212, 175, 55, 0.2);
}

.action-group h4 {
    color: var(--accent);
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.action-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

.btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 10px 20px;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;
    border: none;
    transition: all 0.3s;
}

.btn-success {
    background: linear-gradient(45deg, #28a745, #20c997);
    color: white;
}

.btn-success:hover {
    background: linear-gradient(45deg, #20c997, #28a745);
    transform: translateY(-2px);
}

.btn-danger {
    background: linear-gradient(45deg, #dc3545, #c82333);
    color: white;
}

.btn-danger:hover {
    background: linear-gradient(45deg, #c82333, #dc3545);
    transform: translateY(-2px);
}

.btn-warning {
    background: linear-gradient(45deg, #ffc107, #e0a800);
    color: #212529;
}

.btn-warning:hover {
    background: linear-gradient(45deg, #e0a800, #ffc107);
    transform: translateY(-2px);
}

.btn-primary {
    background: linear-gradient(45deg, #007bff, #0056b3);
    color: white;
}

.btn-primary:hover {
    background: linear-gradient(45deg, #0056b3, #007bff);
    transform: translateY(-2px);
}

.btn-info {
    background: linear-gradient(45deg, #17a2b8, #138496);
    color: white;
}

.btn-info:hover {
    background: linear-gradient(45deg, #138496, #17a2b8);
    transform: translateY(-2px);
}

.btn-secondary {
    background: rgba(108, 117, 125, 0.2);
    color: #adb5bd;
    border: 1px solid #6c757d;
}

.btn-secondary:hover {
    background: rgba(108, 117, 125, 0.4);
    transform: translateY(-2px);
}

.text-right {
    text-align: right;
}

/* Адаптивность */
@media (max-width: 768px) {
    .summary-row {
        flex-direction: column;
        gap: 20px;
    }
    
    .action-buttons {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
        justify-content: center;
    }
}
</style>

<script>
// Функции для работы с заказом
function completeOrder(orderId) {
    if (confirm('Завершить заказ #' + orderId + '?')) {
        alert('Заказ #' + orderId + ' завершен! (демо)');
        location.reload();
    }
}

function cancelOrder(orderId) {
    if (confirm('Отменить заказ #' + orderId + '?')) {
        alert('Заказ #' + orderId + ' отменен! (демо)');
        location.reload();
    }
}

function reopenOrder(orderId) {
    if (confirm('Переоткрыть заказ #' + orderId + '?')) {
        alert('Заказ #' + orderId + ' переоткрыт! (демо)');
        location.reload();
    }
}

function printReceipt(orderId) {
    alert('Печать чека для заказа #' + orderId + ' (демо)');
    // В реальной системе здесь был бы вызов API для печати чека
}

// Автоматическая прокрутка к началу при загрузке
document.addEventListener('DOMContentLoaded', function() {
    window.scrollTo(0, 0);
    
    // Подсветка текущей страницы в меню
    const currentPage = 'order_details.php';
    document.querySelectorAll('.nav-link').forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.style.backgroundColor = 'rgba(212, 175, 55, 0.2)';
            link.style.color = 'var(--accent)';
        }
    });
});

// Отключение отправки формы (для демо)
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('В демо-режиме данные не сохраняются');
    });
});
</script>

<?php 
ob_end_flush(); // Отправляем буфер вывода
require_once 'footer.php'; 
?>