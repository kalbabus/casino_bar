<?php
// process_order.php - обработчик создания заказа
require_once 'config.php';

// Проверка авторизации
if (isGuest()) {
    header('Location: login.php');
    exit;
}

// Обработка POST-запроса
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $guest_id = !empty($_POST['guest_id']) ? (int)$_POST['guest_id'] : null;
    $order_type = $_POST['order_type'] ?? 'bar';
    $total_amount = (float)$_POST['total_amount'];
    $status = $_POST['status'] ?? 'pending';
    $notes = $_POST['notes'] ?? '';
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO orders (guest_id, order_type, total_amount, status, notes, order_time) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([$guest_id, $order_type, $total_amount, $status, $notes]);
        
        $order_id = $pdo->lastInsertId();
        
        // Перенаправление с сообщением об успехе
        header('Location: orders.php?success=1&id=' . $order_id);
        exit;
        
    } catch (Exception $e) {
        // Если ошибка, покажем форму снова с ошибкой
        header('Location: orders.php?add=1&error=' . urlencode($e->getMessage()));
        exit;
    }
} else {
    // Если не POST-запрос, вернуть на страницу заказов
    header('Location: orders.php');
    exit;
}
?>