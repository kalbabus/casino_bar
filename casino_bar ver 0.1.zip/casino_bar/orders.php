<?php
// orders.php - исправленная версия
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';
require_once 'header.php';

// Проверка авторизации
if (isGuest()) {
    echo "<script>alert('Требуется авторизация!'); window.location.href='login.php';</script>";
    exit;
}

// Обработка добавления нового заказа
$message = '';
if (isset($_GET['add'])) {
    $message = '<div class="alert alert-success"><i class="fas fa-check-circle"></i> Режим добавления нового заказа</div>';
}
?>

<div class="container">
    <h1><i class="fas fa-credit-card"></i> Заказы</h1>
    
    <?php echo $message; ?>
    
    <div class="card">
        <div class="card-header">
            <h3>Список заказов</h3>
            <a href="?add" class="btn btn-primary">
                <i class="fas fa-plus"></i> Новый заказ
            </a>
        </div>
        
        <div class="card-body">
            <?php
            try {
                // Сначала проверим, есть ли таблица orders
                $stmt = $pdo->query("SHOW TABLES LIKE 'orders'");
                if ($stmt->rowCount() == 0) {
                    echo '<div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i> 
                            Таблица "orders" не найдена. <br>
                            <a href="setup.php" class="btn btn-sm btn-warning mt-2">Создать таблицы</a>
                          </div>';
                } else {
                    // Пробуем получить данные
                    $stmt = $pdo->query("SELECT o.*, g.first_name, g.last_name 
                                        FROM orders o 
                                        LEFT JOIN guests g ON o.guest_id = g.id 
                                        ORDER BY o.order_time DESC 
                                        LIMIT 20");
                    
                    if ($stmt && $stmt->rowCount() > 0):
            ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Гость</th>
                        <th>Тип</th>
                        <th>Сумма</th>
                        <th>Время</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $stmt->fetch()): ?>
                    <tr>
                        <td>#<?php echo escape($row['id'] ?? 'N/A'); ?></td>
                        <td>
                            <?php if (!empty($row['guest_id'])): ?>
                                <?php echo escape($row['first_name'] . ' ' . $row['last_name']); ?>
                            <?php else: ?>
                                <em>Гость (без регистрации)</em>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="order-type order-type-<?php echo $row['order_type'] ?? 'bar'; ?>">
                                <?php echo ($row['order_type'] ?? 'bar') == 'game' ? '🎰 Игра' : '🍸 Бар'; ?>
                            </span>
                        </td>
                        <td class="amount-cell"><?php echo number_format($row['total_amount'] ?? 0, 0); ?> ₽</td>
                        <td>
                            <?php 
                            if (!empty($row['order_time'])) {
                                echo date('d.m.Y H:i', strtotime($row['order_time']));
                            } else {
                                echo 'Н/Д';
                            }
                            ?>
                        </td>
                        <td>
                            <span class="status status-<?php echo strtolower($row['status'] ?? 'pending'); ?>">
                                <?php echo escape($row['status'] ?? 'В ожидании'); ?>
                            </span>
                        </td>
                        <td>
                            <a href="order_details.php?order_id=<?php echo $row['id']; ?>" class="btn-action btn-view" title="Просмотреть детали">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="?edit=<?php echo $row['id']; ?>" class="btn-action btn-edit" title="Редактировать">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="no-data">
                <i class="fas fa-credit-card" style="font-size: 3em; opacity: 0.3;"></i>
                <p>Нет данных о заказах</p>
                <p class="text-muted">Создайте первый заказ или проверьте подключение к базе данных</p>
                <div class="mt-3">
                    <a href="?add" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Создать первый заказ
                    </a>
                    <a href="setup.php" class="btn btn-secondary">
                        <i class="fas fa-database"></i> Проверить базу данных
                    </a>
                </div>
            </div>
            <?php endif; ?>
                <?php } // конец else ?>
            <?php } catch (Exception $e) { ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-triangle"></i> Ошибка загрузки данных: <?php echo $e->getMessage(); ?>
                <div class="mt-2">
                    <small>Возможные причины:</small>
                    <ul class="mt-1">
                        <li>Отсутствует таблица orders</li>
                        <li>Проблема с подключением к базе данных</li>
                        <li>Ошибка в SQL-запросе</li>
                    </ul>
                </div>
                <a href="setup.php" class="btn btn-sm btn-danger mt-2">
                    <i class="fas fa-tools"></i> Исправить базу данных
                </a>
            </div>
            <?php } ?>
        </div>
    </div>
    
    <!-- Форма для быстрого создания заказа -->
    <?php if (isset($_GET['add'])): ?>
    <div class="card mt-4">
        <div class="card-header">
            <h3><i class="fas fa-plus-circle"></i> Создание нового заказа</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="process_order.php">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="guest_id">Гость:</label>
                        <select id="guest_id" name="guest_id" class="form-control">
                            <option value="">Выберите гостя</option>
                            <?php
                            try {
                                $stmt = $pdo->query("SELECT id, first_name, last_name FROM guests ORDER BY last_name");
                                while ($guest = $stmt->fetch()):
                            ?>
                            <option value="<?php echo $guest['id']; ?>">
                                <?php echo escape($guest['first_name'] . ' ' . $guest['last_name']); ?>
                            </option>
                            <?php endwhile; ?>
                            <?php } catch (Exception $e) { ?>
                            <option value="">Ошибка загрузки гостей</option>
                            <?php } ?>
                        </select>
                        <small class="form-text text-muted">Оставьте пустым для гостя без регистрации</small>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="order_type">Тип заказа:</label>
                        <select id="order_type" name="order_type" class="form-control" required>
                            <option value="bar">Бар (напитки)</option>
                            <option value="game">Игра (ставки)</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="total_amount">Сумма заказа (руб.):</label>
                    <input type="number" id="total_amount" name="total_amount" class="form-control" required min="1" step="0.01" value="1000">
                </div>
                
                <div class="form-group">
                    <label for="status">Статус:</label>
                    <select id="status" name="status" class="form-control">
                        <option value="pending">В ожидании</option>
                        <option value="completed">Завершен</option>
                        <option value="cancelled">Отменен</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="notes">Примечания:</label>
                    <textarea id="notes" name="notes" class="form-control" rows="3" placeholder="Дополнительная информация о заказе"></textarea>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Сохранить заказ
                    </button>
                    <a href="orders.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Отмена
                    </a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
.form-control {
    display: block;
    width: 100%;
    padding: 10px 15px;
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(212, 175, 55, 0.3);
    border-radius: 5px;
    color: white;
    font-size: 1rem;
    transition: all 0.3s;
}

.form-control:focus {
    outline: none;
    border-color: var(--secondary);
    background: rgba(255, 255, 255, 0.15);
}

.form-group {
    margin-bottom: 20px;
}

.form-row {
    display: flex;
    flex-wrap: wrap;
    margin-right: -10px;
    margin-left: -10px;
}

.form-row > .form-group {
    padding-right: 10px;
    padding-left: 10px;
}

.col-md-6 {
    flex: 0 0 50%;
    max-width: 50%;
}

.form-text {
    display: block;
    margin-top: 5px;
    font-size: 0.875em;
    color: var(--secondary-light);
}

.btn {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 10px 20px;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;
    border: none;
    transition: all 0.3s;
}

.btn-success {
    background: linear-gradient(45deg, #28a745, #20c997);
    color: white;
}

.btn-success:hover {
    background: linear-gradient(45deg, #20c997, #28a745);
    transform: translateY(-2px);
}

.btn-secondary {
    background: rgba(108, 117, 125, 0.2);
    color: #adb5bd;
    border: 1px solid #6c757d;
}

.btn-secondary:hover {
    background: rgba(108, 117, 125, 0.4);
    transform: translateY(-2px);
}

.mt-2 { margin-top: 10px; }
.mt-3 { margin-top: 15px; }
.mt-4 { margin-top: 20px; }

.text-muted {
    color: var(--secondary-light);
}

.alert {
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
}

.alert-success {
    background: rgba(40, 167, 69, 0.2);
    border: 1px solid rgba(40, 167, 69, 0.5);
    color: #90EE90;
}

.alert-warning {
    background: rgba(255, 193, 7, 0.2);
    border: 1px solid rgba(255, 193, 7, 0.5);
    color: #FFD700;
}

.alert-error {
    background: rgba(220, 53, 69, 0.2);
    border: 1px solid rgba(220, 53, 69, 0.5);
    color: #FF7F7F;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Автоподсчет суммы при изменении типа заказа
    const orderTypeSelect = document.getElementById('order_type');
    const amountInput = document.getElementById('total_amount');
    
    if (orderTypeSelect && amountInput) {
        orderTypeSelect.addEventListener('change', function() {
            if (this.value === 'game') {
                amountInput.value = 5000; // Средняя ставка в игре
            } else {
                amountInput.value = 1000; // Средний чек в баре
            }
        });
    }
    
    // Валидация формы
    const orderForm = document.querySelector('form');
    if (orderForm) {
        orderForm.addEventListener('submit', function(e) {
            const amount = amountInput ? amountInput.value : 0;
            if (amount <= 0) {
                e.preventDefault();
                alert('Сумма заказа должна быть больше 0');
                amountInput.focus();
            }
        });
    }
});
</script>

<?php require_once 'footer.php'; ?>